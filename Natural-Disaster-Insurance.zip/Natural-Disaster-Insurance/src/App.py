from flask import Flask, render_template, request, jsonify
from web3 import Web3
import json

app = Flask(__name__)

# Connect to local Ethereum node (Ganache)
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))

# Check if connected to Ganache
if not w3.isConnected():
    print("Failed to connect to the Ethereum node.")
    exit()

# Load the smart contract
with open('../build/contracts/Insurance.json') as f:
    contract_json = json.load(f)
    contract_address = contract_json['networks']['5777']['address']
    contract = w3.eth.contract(address=contract_address, abi=contract_json['abi'])

# Default account
w3.eth.default_account = '0x1C0046662606c07E5eF73A1e63FB09F626b1cAA8'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/buy_policy_page')
def buy_policy_page():
    return render_template('index.html', page="buy_policy")

@app.route('/buy_policy', methods=['POST'])
def buy_policy():
    premium = request.json.get('premium')
    payout = request.json.get('payout')
    
    try:
        tx_hash = contract.functions.buyPolicy(Web3.toWei(payout, 'ether')).transact({'from': w3.eth.default_account, 'value': Web3.toWei(premium, 'ether')})
        w3.eth.waitForTransactionReceipt(tx_hash)
        return jsonify({"message": "Policy purchased successfully!"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/claim_payout_page')
def claim_payout_page():
    return render_template('index.html', page="claim_payout")

@app.route('/claim_payout', methods=['POST'])
def claim_payout():
    try:
        tx_hash = contract.functions.claimPayout().transact({'from': w3.eth.default_account})
        w3.eth.waitForTransactionReceipt(tx_hash)
        return jsonify({"message": "Payout claimed successfully!"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/get_policy_page')
def get_policy_page():
    return render_template('index.html', page="get_policy")

@app.route('/get_policy', methods=['GET'])
def get_policy():
    try:
        policy = contract.functions.getPolicy().call({'from': w3.eth.default_account})
        return jsonify({
            "premium": policy[0],
            "payout": policy[1],
            "isActive": policy[2],
            "claimed": policy[3]
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(debug=True)
